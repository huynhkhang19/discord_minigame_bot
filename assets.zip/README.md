<h1 align="center"><img src="./assets/logo.gif" width="30px"> Discord MiniGame Bot <img src="./assets/logo.gif" width="30px"></h1>

## ✨Latest Updates

Go check it out [HERE!](https://github.com/huynhkhang19/discord_minigame_bot/)

## 🚧 | Prerequisites

- [Node.js 16+](https://nodejs.org/en/download/)

## 📝 | Tutorial

### 💪🏻 Non-Docker
> The `config.js` file should be configured first.

Install all dependencies and deploy Slash Commands
```sh
npm install
npm run deploy
```
Start the bot
```sh
node index.js
```
