module.exports.startTyping = async function(channel){
	await channel.sendTyping();
};